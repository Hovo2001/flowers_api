export { default as ProductsModel } from './products.model';
export { default as UsersModel } from './users.model';
export { default as SlidesModel } from './slides.model';
export { default as FootersModel } from './footers.model';
export { default as OrdersModel } from './orders.model';
export { default as SuperAdminModel } from './superAdmin.model';
