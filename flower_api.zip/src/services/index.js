export { default as Service } from './service';
export { default as CategoryService } from './category.service';
export { default as UsersService } from './users.service';
export { default as SlideService } from './slide.service';
export { default as FooterService } from './footer.service';
export { default as OrdersService } from './orders.service';
export { default as superAdminServices } from './superAdmin.service'