const messageStatus = {
  sended: 'sended',
  received: 'received',
  seen: 'seen'
};

export default messageStatus;
