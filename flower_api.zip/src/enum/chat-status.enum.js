const chatStatus = {
  accepted: 'accepted',
  declined: 'declined',
  not_selected: 'not-selected'
};

export default chatStatus;
