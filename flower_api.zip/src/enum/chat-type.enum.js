const chatType = {
  private: 'private',
  group: 'group'
};

export default chatType;
